var searchData=
[
  ['getalldata',['getAllData',['../class_lib_mng_sys.html#a8f762d0b6a24d104c16ded343722f44e',1,'LibMngSys']]],
  ['getdata',['getData',['../class_lib_mng_sys.html#aeba0b53cc1ca86595f7062543bce8288',1,'LibMngSys']]]
];
