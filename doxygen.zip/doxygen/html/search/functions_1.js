var searchData=
[
  ['deletedata',['deleteData',['../class_lib_mng_sys.html#ad6d0dcae44d83966640a51b57bc0e541',1,'LibMngSys']]]
];
