var searchData=
[
  ['text',['text',['../structsingle_search_param_3_01name_01_4.html#a1a530d327936a3e9fca8e312420e14b2',1,'singleSearchParam&lt; name &gt;::text()'],['../structsingle_search_param_3_01author_01_4.html#a5bc0b1d133a40c91f541b0c214339f14',1,'singleSearchParam&lt; author &gt;::text()'],['../structsingle_search_param_3_01year_01_4.html#a2678a3e5fdc28197c2b7d728c91e4ca0',1,'singleSearchParam&lt; year &gt;::text()']]]
];
