var searchData=
[
  ['savechanges',['saveChanges',['../class_lib_mng_sys.html#a7f3f32f4d9d4b85dbc77c1f3713bdfdf',1,'LibMngSys']]],
  ['singlesearchparam',['singleSearchParam',['../structsingle_search_param.html',1,'']]],
  ['singlesearchparam_3c_20author_20_3e',['singleSearchParam&lt; author &gt;',['../structsingle_search_param_3_01author_01_4.html',1,'']]],
  ['singlesearchparam_3c_20name_20_3e',['singleSearchParam&lt; name &gt;',['../structsingle_search_param_3_01name_01_4.html',1,'']]],
  ['singlesearchparam_3c_20year_20_3e',['singleSearchParam&lt; year &gt;',['../structsingle_search_param_3_01year_01_4.html',1,'']]]
];
