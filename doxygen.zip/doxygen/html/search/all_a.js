var searchData=
[
  ['refreshdb',['RefreshDB',['../class_main_window.html#a1b2f1aa629a531b1ed7562d287fb44a8',1,'MainWindow']]]
];
