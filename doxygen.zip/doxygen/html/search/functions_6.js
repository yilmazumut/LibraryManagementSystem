var searchData=
[
  ['savechanges',['saveChanges',['../class_lib_mng_sys.html#a7f3f32f4d9d4b85dbc77c1f3713bdfdf',1,'LibMngSys']]]
];
