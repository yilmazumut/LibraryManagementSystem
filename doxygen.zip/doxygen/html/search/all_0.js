var searchData=
[
  ['addbook',['addBook',['../classadd_book.html',1,'']]],
  ['author',['author',['../structauthor.html',1,'']]]
];
