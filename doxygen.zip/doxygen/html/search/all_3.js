var searchData=
[
  ['deletedata',['deleteData',['../class_lib_mng_sys.html#ad6d0dcae44d83966640a51b57bc0e541',1,'LibMngSys']]],
  ['dialog',['Dialog',['../class_dialog.html',1,'']]],
  ['doublesearchparam',['doubleSearchParam',['../structdouble_search_param.html',1,'']]],
  ['doublesearchparam_3c_20author_2c_20year_20_3e',['doubleSearchParam&lt; author, year &gt;',['../structdouble_search_param_3_01author_00_01year_01_4.html',1,'']]],
  ['doublesearchparam_3c_20name_2c_20author_20_3e',['doubleSearchParam&lt; name, author &gt;',['../structdouble_search_param_3_01name_00_01author_01_4.html',1,'']]],
  ['doublesearchparam_3c_20name_2c_20year_20_3e',['doubleSearchParam&lt; name, year &gt;',['../structdouble_search_param_3_01name_00_01year_01_4.html',1,'']]]
];
